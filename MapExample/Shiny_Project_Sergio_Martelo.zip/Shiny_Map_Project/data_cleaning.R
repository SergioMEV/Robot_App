### This file contains all my data cleaning 

##Libraries 
library(tidyverse)

## Cleaning GDP dataset
tempGDP <- data.frame(read.csv("data/GDP.csv")) %>%
  select(Gross.domestic.product.2020, X.1, X.2)

GDP <- tempGDP[-c(1:4),]
GDP <- GDP[-c(207:329),]

#Tidying names and variables
colnames(GDP)[colnames(GDP) %in%
                     c("Gross.domestic.product.2020", "X.1", "X.2")] <- 
                      c("GDP_Ranking", "Country" ,"GDP_Value")
GDP <- mutate(GDP,
       GDP_Ranking = as.numeric(GDP_Ranking),
       GDP_Value = parse_number(GDP_Value))

## Cleaning POP dataset

tempPOP <- data.frame(read.csv("data/POP.csv")) %>%
  select(Population.2020, X.1, X.2)

POP <- tempPOP[-c(1:4),]

POP <- POP[-c(217:328)]

colnames(POP)[colnames(POP) %in%
                c("Population.2020", "X.1", "X.2")] <- 
                c("POP_Ranking", "Country" ,"POP_Value")

POP <- mutate(POP,
              POP_Ranking = as.numeric(POP_Ranking),
              POP_Value = parse_number(POP_Value))

POP_GDP <- inner_join(POP,GDP, by = "Country") 

colnames(POP_GDP)[colnames(POP_GDP) %in% 
                    c("Country")] <- c("name")

## Getting region and income group

WGI_country <- read_csv("data/WGICountry.csv") %>% 
  select(`Short Name`, Region, `Income Group`) 

POP_GDP <- right_join( WGI_country, POP_GDP, by = c("Short Name"="name"))

colnames(POP_GDP)[which(names(POP_GDP) == "Short Name")] <- "name"

colnames(POP_GDP)[which(names(POP_GDP) == "Income Group")] <- "Income_Group"

## Pie chart data

WID_Data_top_10 <- read_csv("data/WID_Data.csv") %>% 
  select(name, top10per)

WID_Data_top_1 <- read_csv("data/WIDTOP1.csv") %>% 
  select(name, top1per)

WID_Data <- full_join(WID_Data_top_1,WID_Data_top_10, by = c("name" = "name"))

WID_Data_bot_50 <- read_csv("data/WIDBOT50.csv") %>% 
  select(name, bot50per)

WID_Data <- full_join(WID_Data,WID_Data_bot_50, by = c("name" = "name"))

WID_Data_mid_40 <- read_csv("data/WIDMID40.csv") %>% 
  select(name, mid40per)

WID_Data <- full_join(WID_Data,WID_Data_mid_40, by = c("name" = "name"))

POP_GDP <- full_join(POP_GDP,WID_Data, by = c("name" = "name"))

POP_GDP <- POP_GDP[-c(205:353),]

## jSON files
shapeurl <- "https://raw.githubusercontent.com/johan/world.geo.json/master/countries.geo.json"
WorldCountry <- geojson_read(shapeurl, what = "sp")
(WorldCountry@data)


##Joining names to data

POP_GDP_by_country <- left_join(data.frame(name = WorldCountry$name), 
                                POP_GDP, by = c("name" = "name"))

# Getting row numbers to maintain order of data
WorldCountry@data$rownum<- 1:nrow(WorldCountry@data)

#Merging data
Correct_POP_GDP <- merge(
  WorldCountry@data, POP_GDP_by_country, by="name") %>%
  arrange(rownum, desc()) %>% 
  select(id,name, POP_Ranking, POP_Value,GDP_Ranking,GDP_Value,Region, Income_Group, top10per.x, top1per,bot50per,mid40per)


## Creating final CSV
write.csv(Correct_POP_GDP, "POP_GDP.csv")







